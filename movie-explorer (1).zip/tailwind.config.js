/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0A0A0D',
        surface: '#141419',
        surface2: '#1B1B22',
        red: '#E4362E',
        orange: '#F2994A',
        gold: '#F5B400',
        cream: '#F5F5F0',
        muted: '#8B8B94',
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"Manrope"', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
