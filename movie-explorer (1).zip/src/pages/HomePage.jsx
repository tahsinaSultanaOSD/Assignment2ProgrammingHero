import HeroBanner from '../components/HeroBanner.jsx'
import TrendingSpotlights from '../components/TrendingSpotlights.jsx'

export default function HomePage() {
  return (
    <>
      <HeroBanner />
      <TrendingSpotlights />
    </>
  )
}
